﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace CandidateManagement_WPF_X
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
